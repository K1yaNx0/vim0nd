const $ = (s) => document.querySelector(s);
const welcome = $('#welcomeScreen');
const panels = ['#step1','#step2','#step3','#stepDone'].map($);
const navStep = $('#navStep'), progressBar = $('#progressBar'), progressText = $('#progressText'), progressPercent = $('#progressPercent');
let currentStep = 0, feedbackText = '', rating = 0, gameScore = 0;
const fa = n => String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
function showToast(message){const t=$('#toast');t.textContent=message;t.classList.add('show');clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>t.classList.remove('show'),2600)}
function updateProgress(step){const data=[['شروع تجربه ویموند',0,'مرحله ۱ از ۳'],['ثبت نظر شما',33,'مرحله ۱ از ۳'],['امتیازدهی به ارائه',66,'مرحله ۲ از ۳'],['بازی و ثبت نهایی',88,'مرحله ۳ از ۳'],['بازخورد ثبت شد',100,'تکمیل شد']];let d=data[step]||data[0];progressBar.style.width=d[1]+'%';progressText.textContent=d[0];progressPercent.textContent=fa(d[1])+'٪';navStep.textContent=d[2]}
function showPanel(index){welcome.classList.add('hidden');panels.forEach(p=>p.classList.add('hidden'));if(index===0)panels[0].classList.remove('hidden');else if(index===1)panels[1].classList.remove('hidden');else if(index===2)panels[2].classList.remove('hidden');else panels[3].classList.remove('hidden');currentStep=index;updateProgress(index+1);window.scrollTo({top:0,behavior:'smooth'})}
setTimeout(()=>{welcome.classList.add('fade-out');setTimeout(()=>{welcome.classList.add('hidden');panels[0].classList.remove('hidden');updateProgress(1)},560)},3000);
$('#feedback').addEventListener('input',e=>{$('#charCount').textContent=fa(e.target.value.length)+' / ۸۰۰'});
$('#feedbackForm').addEventListener('submit',e=>{e.preventDefault();feedbackText=$('#feedback').value.trim();if(feedbackText.length<3){showToast('لطفاً نظرتون رو کمی کامل‌تر بنویسید.');return}showPanel(1)});
const stars=[...document.querySelectorAll('.star')];
function setRating(value){rating=value;stars.forEach(s=>s.classList.toggle('selected',+s.dataset.rating<=value));$('#ratingNumber').innerHTML=fa(value)+' <small>از ۵</small>';$('#ratingText').textContent=['','اصلاً راضی نبودم','نیاز به بهتر شدن داره','خوب بود','خیلی خوب بود','عالی بود! ممنون از نظرتون'][value];$('#toGame').disabled=false;$('#ratingHint').textContent='امتیاز شما: '+fa(value)+' از ۵'}
stars.forEach(s=>{s.addEventListener('click',()=>setRating(+s.dataset.rating));s.addEventListener('mouseenter',()=>stars.forEach(x=>x.classList.toggle('hovered',+x.dataset.rating<=+s.dataset.rating)));s.addEventListener('mouseleave',()=>stars.forEach(x=>x.classList.remove('hovered')))});
$('#toGame').addEventListener('click',()=>{showPanel(2);drawGame()});

// Snake game: canvas scales visually while using a fixed logical grid.
const canvas=$('#gameCanvas'), ctx=canvas.getContext('2d'), grid=20, cols=30, rows=18;
let snake=[{x:9,y:9},{x:8,y:9},{x:7,y:9}], dir={x:1,y:0}, nextDir={x:1,y:0}, apple={x:17,y:8}, running=false, gameOver=false, timer=null, soundOn=true, audioCtx=null;
function randomApple(){let p;do{p={x:Math.floor(Math.random()*cols),y:Math.floor(Math.random()*rows)}}while(snake.some(s=>s.x===p.x&&s.y===p.y));return p}
function roundedRect(c,x,y,w,h,r){c.beginPath();c.roundRect(x,y,w,h,r);c.fill()}
function drawGame(){const w=canvas.width,h=canvas.height;ctx.clearRect(0,0,w,h);ctx.fillStyle='#fff9fa';ctx.fillRect(0,0,w,h);
ctx.strokeStyle='#f8e8eb';ctx.lineWidth=1;for(let x=0;x<=w;x+=grid){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,h);ctx.stroke()}for(let y=0;y<=h;y+=grid){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke()}
ctx.save();ctx.shadowColor='#ff315744';ctx.shadowBlur=10;ctx.fillStyle='#f02b50';roundedRect(ctx,apple.x*grid+3,apple.y*grid+3,grid-6,grid-6,7);ctx.restore();ctx.fillStyle='#278d50';ctx.beginPath();ctx.ellipse(apple.x*grid+13,apple.y*grid+4,4,2,-.6,0,Math.PI*2);ctx.fill();
snake.forEach((s,i)=>{ctx.fillStyle=i===0?'#a90e24':'#d81e3a';roundedRect(ctx,s.x*grid+2,s.y*grid+2,grid-4,grid-4,6);if(i===0){ctx.fillStyle='white';ctx.beginPath();ctx.arc(s.x*grid+8,s.y*grid+8,2,0,Math.PI*2);ctx.arc(s.x*grid+14,s.y*grid+8,2,0,Math.PI*2);ctx.fill()}});
if(!running){ctx.fillStyle='#ffffffd9';ctx.fillRect(0,0,w,h);ctx.fillStyle='#9e1127';ctx.textAlign='center';ctx.font='700 22px Vazirmatn, sans-serif';ctx.fillText(gameOver?'بازی تموم شد!':'آماده‌ای برای جمع کردن سیب؟',w/2,h/2-7);ctx.fillStyle='#88818a';ctx.font='13px Vazirmatn, sans-serif';ctx.fillText(gameOver?'برای تلاش دوباره شروع بازی رو بزن':'برای شروع، دکمه پایین رو بزن',w/2,h/2+22)}}
function beep(freq=550,duration=.08){if(!soundOn)return;try{audioCtx=audioCtx||new(window.AudioContext||window.webkitAudioContext)();const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type='sine';o.frequency.value=freq;g.gain.setValueAtTime(.055,audioCtx.currentTime);g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+duration);o.connect(g);g.connect(audioCtx.destination);o.start();o.stop(audioCtx.currentTime+duration)}catch(e){}}
function startGame(){clearInterval(timer);snake=[{x:9,y:9},{x:8,y:9},{x:7,y:9}];dir={x:1,y:0};nextDir={x:1,y:0};apple=randomApple();gameScore=0;gameOver=false;running=true;$('#score').textContent='۰';$('#gameStatus').textContent='سیب‌ها رو جمع کن!';$('#startGame').textContent='شروع دوباره ▶';$('#gameHint').textContent='۵ سیب جمع کن تا ثبت نهایی فعال بشه.';drawGame();timer=setInterval(tick,125)}
function tick(){if(!running)return;dir=nextDir;const head={x:snake[0].x+dir.x,y:snake[0].y+dir.y};if(head.x<0||head.y<0||head.x>=cols||head.y>=rows||snake.some((s,i)=>i<snake.length-1&&s.x===head.x&&s.y===head.y)){endGame();return}snake.unshift(head);if(head.x===apple.x&&head.y===apple.y){gameScore++;$('#score').textContent=fa(gameScore);apple=randomApple();beep(760,.1);if(gameScore>=5){$('#finishBtn').disabled=false;$('#gameHint').textContent='آفرین! حالا می‌تونی بازخوردت رو ثبت کنی.';$('#gameStatus').textContent='مرحله بازی تکمیل شد ✓'} }else snake.pop();drawGame()}
function endGame(){running=false;gameOver=true;clearInterval(timer);beep(190,.2);$('#gameStatus').textContent='برخورد کردی؛ دوباره تلاش کن';drawGame()}
function changeDir(d){const dirs={up:{x:0,y:-1},down:{x:0,y:1},left:{x:-1,y:0},right:{x:1,y:0}};const n=dirs[d];if(n&&!(n.x===-dir.x&&n.y===-dir.y))nextDir=n}
document.addEventListener('keydown',e=>{const map={ArrowUp:'up',w:'up',ArrowDown:'down',s:'down',ArrowLeft:'left',a:'left',ArrowRight:'right',d:'right'};if(map[e.key]){e.preventDefault();changeDir(map[e.key])}});
document.querySelectorAll('.mobile-controls button').forEach(b=>{b.addEventListener('click',()=>changeDir(b.dataset.dir));b.addEventListener('touchstart',e=>{e.preventDefault();changeDir(b.dataset.dir)},{passive:false})});
$('#startGame').addEventListener('click',startGame);
$('#soundToggle').addEventListener('click',()=>{soundOn=!soundOn;$('#soundToggle').textContent=soundOn?'♫ صدا روشن':'♫ صدا خاموش';$('#soundToggle').setAttribute('aria-pressed',String(soundOn));if(soundOn)beep()});
$('#finishBtn').addEventListener('click',()=>{
  if(gameScore<5){showToast('برای ثبت نهایی، حداقل ۵ امتیاز لازم داری.');return}
  clearInterval(timer);running=false;
  const review={id:Date.now().toString(36)+Math.random().toString(36).slice(2,7),date:new Date().toLocaleString('fa-IR'),comment:feedbackText,rating:rating,gameScore:gameScore};
  try{const reviews=JSON.parse(localStorage.getItem('vimond_reviews')||'[]');reviews.push(review);localStorage.setItem('vimond_reviews',JSON.stringify(reviews));}catch(err){showToast('ذخیره نظر در این مرورگر ممکن نشد.');}
  $('#finalRating').textContent=fa(rating)+' / ۵';$('#finalScore').textContent=fa(gameScore);showPanel(3);
});
$('#restartBtn').addEventListener('click',()=>{feedbackText='';rating=0;gameScore=0;$('#feedback').value='';$('#charCount').textContent='۰ / ۸۰۰';stars.forEach(s=>s.classList.remove('selected'));$('#ratingNumber').innerHTML='— <small>از ۵</small>';$('#ratingText').textContent='برای امتیاز دادن، یک ستاره انتخاب کنید.';$('#toGame').disabled=true;$('#finishBtn').disabled=true;clearInterval(timer);running=false;gameOver=false;panels.forEach(p=>p.classList.add('hidden'));welcome.classList.remove('hidden','fade-out');updateProgress(0);setTimeout(()=>{welcome.classList.add('fade-out');setTimeout(()=>{welcome.classList.add('hidden');panels[0].classList.remove('hidden');updateProgress(1)},560)},3000)});
drawGame();